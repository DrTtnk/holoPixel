import React, { useRef } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Box, Plane, Line, Sphere, Cone } from '@react-three/drei';
import * as THREE from 'three';

interface SceneVisualizerProps {
  currentX: number;
  currentY: number;
  targetX: number;
  targetY: number;
}

export function DiagnosticsVisualizer({ currentX, currentY, targetX, targetY }: SceneVisualizerProps) {
  // Normalize exactly like in Engine.ts
  let nx = (currentX / targetX) * 2.0 - 1.0;
  let ny = (currentY / targetY) * 2.0 - 1.0;
  let hogelPosX = nx * 5.0; // Panel is 10 units wide
  let hogelPosY = ny * 3.75 + 5.0; // Shifted up (+5) to center in the 0..10 tall room

  return (
    <Canvas shadows camera={{ position: [15, 12, -25], fov: 45 }}>
      <ambientLight intensity={0.2} />
      {/* Main simulated light source inside the Cornell Box */}
      <pointLight position={[0, 9, 0]} intensity={180} castShadow shadow-mapSize={[1024, 1024]} shadow-bias={-0.001} />
      
      <OrbitControls target={[0, 4, -5]} />
      
      {/* The Holographic Display Panel */}
      <group position={[0, 5, -10]}>
        {/* Panel outline */}
        <lineSegments>
          <edgesGeometry attach="geometry" args={[new THREE.PlaneGeometry(10, 7.5)] as any} />
          <lineBasicMaterial attach="material" color="#4f46e5" />
        </lineSegments>
        <Plane args={[10, 7.5]} material-color="#111" material-transparent material-opacity={0.3} />
      </group>

      {/* Current Hogel Indicator */}
      <mesh position={[hogelPosX, hogelPosY, -10]}>
        <sphereGeometry args={[0.15, 16, 16]} />
        <meshBasicMaterial color="#10b981" />
      </mesh>

      {/* Simulated Reconstructor Camera (The virtual observer / window sensor) */}
      <group position={[0, 5, -20]}>
         {/* Camera body */}
         <Box args={[1, 1, 1.5]} material-color="#555" />
         {/* Camera Lens */}
         <Cone args={[0.5, 1, 16]} position={[0, 0, 1]} rotation={[-Math.PI/2, 0, 0]} material-color="#222" />
         {/* Viewing Frustum outlining the "Expanding Window" projection towards the panel */}
         <lineSegments>
           <edgesGeometry attach="geometry" args={[new THREE.EdgesGeometry(new THREE.ConeGeometry(5.8, 10, 4, 1, true))] as any} />
           <lineBasicMaterial attach="material" color="#4f46e5" opacity={0.2} transparent />
         </lineSegments>
      </group>

      {/* Rays pointing from current hogel into scene */}
      <Line 
         points={[
           [hogelPosX, hogelPosY, -10],
           [0, 5, 0] // pointing to center of Cornell box roughly
         ]} 
         color="#10b981" 
         opacity={0.4} 
         transparent 
      />

      {/* The Cornell Box Environment */}
      <group position={[0, 5, 0]}>
         {/* Floor & Ceiling & Back */}
         <Plane args={[10, 10]} position={[0, -5, 0]} rotation={[-Math.PI/2, 0, 0]} receiveShadow material-color="#cccccc" />
         <Plane args={[10, 10]} position={[0, 5, 0]} rotation={[Math.PI/2, 0, 0]} receiveShadow material-color="#cccccc" />
         <Plane args={[10, 10]} position={[0, 0, 5]} rotation={[Math.PI, 0, 0]} receiveShadow material-color="#cccccc" />
         
         {/* Walls */}
         <Plane args={[10, 10]} position={[-5, 0, 0]} rotation={[0, Math.PI/2, 0]} receiveShadow material-color="#cc2222" /> {/* Left Red */}
         <Plane args={[10, 10]} position={[5, 0, 0]} rotation={[0, -Math.PI/2, 0]} receiveShadow material-color="#22cc22" /> {/* Right Green */}
      </group>

      {/* Light Source Indicator */}
      <Sphere args={[1, 16, 16]} position={[0, 9.9, 0]}>
        <meshBasicMaterial color="#ffffff" />
      </Sphere>

      {/* Scene Elements */}
      <group position={[0, 0, 0]}>
         {/* Sphere */}
         <Sphere args={[1.5, 32, 32]} position={[-2, 1.5, -1]} castShadow receiveShadow>
           <meshLambertMaterial color="#ccccdd" />
         </Sphere>
         
         {/* Rotated Box */}
         <Box args={[2.4, 3.0, 2.4]} position={[2, 1.5, 1]} rotation={[0, -0.4, 0]} castShadow receiveShadow>
           <meshLambertMaterial color="#e5cc33" />
         </Box>
      </group>
    </Canvas>
  );
}
