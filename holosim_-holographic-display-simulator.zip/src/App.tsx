/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Activity, Aperture, Layers, Cpu, Play, Pause } from "lucide-react";
import { useEffect, useRef, useState, useCallback } from "react";
import { SimulationEngine } from "./simulator/Engine";

import { DiagnosticsVisualizer } from "./components/DiagnosticsVisualizer";

function PreviewCanvas({ data, width, height, label }: { data?: Uint8ClampedArray, width: number, height: number, label: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (data && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        ctx.putImageData(new ImageData(data, width, height), 0, 0);
      }
    }
  }, [data, width, height]);

  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs text-neutral-500 font-mono">{label}</span>
      <canvas 
        ref={canvasRef} 
        width={width} 
        height={height} 
        className="w-full aspect-square bg-neutral-950 border border-neutral-800 rounded-lg" 
        style={{ imageRendering: 'pixelated' }}
      />
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<SimulationEngine | null>(null);
  const [running, setRunning] = useState(false);
  const [stats, setStats] = useState({
    computed: 0,
    total: 480000,
    subpixels: 0,
    currentX: 0,
    currentY: 0,
    hogelsPerSecond: 0,
    previews: null as any
  });

  // Initialize engine
  useEffect(() => {
    if (!canvasRef.current) return;
    
    try {
      const engine = new SimulationEngine(canvasRef.current);
      engine.onProgressUpdate = setStats;
      engineRef.current = engine;
      // Do a single draw to show the black sensor canvas
      engine.computeNextPatch(0); 
    } catch (e) {
      console.error(e);
    }
    
    return () => {
      engineRef.current = null;
    };
  }, []);

  // Main compute loop
  useEffect(() => {
    let handle: number;
    const loop = () => {
      if (running && engineRef.current && engineRef.current.currentHogelY < 600) {
        // Compute chunks. Number of patches per frame determines interaction speed.
        // Higher = faster accumulation, lower = slower but browser stays responsive.
        engineRef.current.computeNextPatch(16);
        handle = requestAnimationFrame(loop);
      }
    };
    if (running) handle = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(handle);
  }, [running]);

  const toggleCompute = useCallback(() => {
    setRunning(r => !r);
  }, []);

  const progressPct = ((stats.computed / stats.total) * 100).toFixed(2);
  const billionsSubpixels = (stats.subpixels / 1000000000).toFixed(2);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-200 font-sans flex flex-col">
      {/* Header */}
      <header className="border-b border-neutral-800 bg-neutral-900 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 rounded-lg">
            <Aperture className={`w-6 h-6 text-indigo-400 ${running ? 'animate-spin-slow' : ''}`} />
          </div>
          <div>
            <h1 className="font-semibold text-lg tracking-tight text-white">HoloSim</h1>
            <p className="text-xs text-neutral-400 font-mono">Phase & Intensity Optical Reconstructor</p>
          </div>
        </div>
        
        <div className="flex gap-4">
          <div className="flex flex-col items-end">
            <span className="text-xs text-neutral-500 font-mono tracking-wider uppercase">Panel Size</span>
            <span className="text-sm font-medium">800 × 600</span>
          </div>
          <div className="w-px h-8 bg-neutral-800"></div>
          <div className="flex flex-col items-end">
            <span className="text-xs text-neutral-500 font-mono tracking-wider uppercase">Subpixel Matrix</span>
            <span className="text-sm font-medium text-emerald-400">512 × 512</span>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Controls Setup */}
        <aside className="w-80 border-r border-neutral-800 bg-neutral-900/50 p-6 flex flex-col gap-6 overflow-y-auto">
          
          <section className="space-y-4">
            <h2 className="text-sm font-medium text-neutral-400 uppercase tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              Compute State
            </h2>
            
            <button
              onClick={toggleCompute}
              className={`w-full flex items-center justify-center gap-2 py-3 rounded-lg font-medium transition-colors ${
                running 
                  ? 'bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-900/20'
              }`}
            >
              {running ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {running ? 'Pause FFT Accumulator' : 'Start Global Pipeline'}
            </button>

            <div className="space-y-3 pt-2">
              <div>
                <div className="flex justify-between text-xs text-neutral-400 mb-1">
                  <span>Progress</span>
                  <span className="font-mono text-indigo-300">{progressPct}%</span>
                </div>
                <div className="h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-500 transition-all duration-300"
                    style={{ width: `${progressPct}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col">
                  <span className="text-neutral-500 mb-1">Speed</span>
                  <span className="font-mono text-emerald-400">{stats.hogelsPerSecond.toLocaleString()} hz</span>
                </div>
                <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col">
                  <span className="text-neutral-500 mb-1">Subpixels</span>
                  <span className="font-mono text-neutral-200 text-indigo-400">{billionsSubpixels}B</span>
                </div>
              </div>
            </div>
          </section>

          {/* Diagnostics Section */}
          <section className="space-y-4">
            <h2 className="text-sm font-medium text-neutral-400 uppercase tracking-wider flex items-center gap-2">
              Diagnostics
            </h2>
            <div className="grid grid-cols-2 gap-3">
               <PreviewCanvas 
                 data={stats.previews?.lightfield} 
                 width={stats.previews?.width || 128} 
                 height={stats.previews?.height || 128} 
                 label="Ray-Traced Lightfield" 
               />
               <PreviewCanvas 
                 data={stats.previews?.fringe} 
                 width={stats.previews?.width || 128} 
                 height={stats.previews?.height || 128} 
                 label="Fringe (Diffraction Phase)" 
               />
            </div>
          </section>
          
          <section className="space-y-4">
            <h2 className="text-sm font-medium text-neutral-400 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Pipeline Architecture
            </h2>
            <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-xl text-sm text-neutral-400 space-y-3">
              <p>
                <strong className="text-neutral-200 block">1. Path Tracer</strong>
                Simulates lightfield hemisphere (64×64) from current hogel ({stats.currentX}, {stats.currentY}).
              </p>
              <div className="w-full h-px bg-neutral-800"></div>
              <p>
                <strong className="text-neutral-200 block">2. Interference Generator</strong>
                Generates 512×512 subpixel diffraction grating from lightfield.
              </p>
              <div className="w-full h-px bg-neutral-800"></div>
              <p>
                <strong className="text-neutral-200 block">3. True FFT Reconstructor</strong>
                Validates the grating mathematically via 2D Radix-2 Ping-Pong passes over diffraction array.
              </p>
              <div className="w-full h-px bg-neutral-800"></div>
              <p>
                <strong className="text-neutral-200 block">4. Camera Sensor (Expanding Window)</strong>
                FFT light map is accumulated with positional parallax.
              </p>
            </div>
            
            <div className="h-64 mt-4 w-full bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden relative">
               <DiagnosticsVisualizer 
                 currentX={stats.currentX} 
                 currentY={stats.currentY} 
                 targetX={800} 
                 targetY={600} 
               />
               <div className="absolute top-2 left-2 px-2 py-1 bg-black/60 backdrop-blur rounded text-[10px] text-neutral-400 font-mono">
                 3D Setup Visualizer (Drag to rotate)
               </div>
            </div>
          </section>

        </aside>

        {/* Viewport View */}
        <section className="flex-1 bg-black relative flex flex-col">
          <div className="absolute inset-0 flex items-center justify-center dashboard-grid p-8">
            <div className="w-[1024px] h-[768px] relative rounded-lg border border-neutral-800 bg-neutral-900 shadow-2xl overflow-hidden shrink-0 flex items-center justify-center">
              {/* Virtual Camera Sensor Accumulation View */}
              <canvas 
                ref={canvasRef}
                width={1024} 
                height={768} 
                className="w-full h-full block" 
                style={{ imageRendering: 'pixelated' }}
              />
              
              {!running && stats.computed === 0 && (
                <div className="absolute inset-0 bg-neutral-950/80 backdrop-blur-sm flex flex-col items-center justify-center text-center z-10 space-y-4">
                  <Play className="w-12 h-12 text-indigo-500 opacity-50" />
                  <h3 className="text-xl font-medium text-white">Press Start</h3>
                  <p className="text-neutral-400 max-w-sm text-sm">
                    Because this browser process physically cannot allocate 120GB of RAM for the full array, we use an expanding-window reconstruction technique.
                  </p>
                </div>
              )}
            </div>
          </div>
          
          <style>{`
            .dashboard-grid {
              background-image: 
                linear-gradient(to right, rgba(255,255,255,0.02) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(255,255,255,0.02) 1px, transparent 1px);
              background-size: 40px 40px;
            }
            .animate-spin-slow {
              animation: spin 4s linear infinite;
            }
            @keyframes spin {
              from { transform: rotate(0deg); }
              to { transform: rotate(360deg); }
            }
          `}</style>
        </section>
      </main>
    </div>
  );
}
